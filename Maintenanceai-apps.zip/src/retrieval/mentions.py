"""@-mention parsing to scope a query to specific documents or file types.

The user can prefix a question with mentions to restrict retrieval, e.g.:
    "@excel berapa stok spare part?"            -> only .xlsx files
    "@MS_INDEX_20250307.xlsx tag 4853-ZY-7611"  -> only that file
    "@excel @SLAG DATASHEET.pdf ..."            -> the union of both

Mentions are matched against the KNOWN set (type aliases + indexed filenames),
longest-match-first, so filenames containing spaces parse correctly. The
matched mention spans are stripped from the text before it goes to the LLM.
"""

# alias -> file extensions it expands to
_TYPE_ALIASES = {
    "excel": (".xlsx", ".xls"),
    "pdf": (".pdf",),
    "word": (".docx",),
    "ppt": (".pptx", ".ppt"),
    "text": (".txt", ".md"),
}


def mention_candidates(files: list[str]) -> list[str]:
    """Autocomplete list: '@'-prefixed type aliases + every indexed filename."""
    return ["@" + a for a in _TYPE_ALIASES] + ["@" + f for f in files]


def parse_mentions(text: str, known_files):
    """Split a query into (file_filter, clean_text).

    file_filter is None when the query has no mention (search everything), or a
    set of filenames to restrict to (possibly empty -> the mention matched no
    indexed file, so the scoped search returns nothing).
    """
    known = list(known_files)
    lower_files = {f.lower(): f for f in known}

    targets: set[str] = set()
    spans: list[tuple[int, int]] = []

    i = 0
    while True:
        at = text.find("@", i)
        if at == -1:
            break
        rest = text[at + 1:]
        rest_l = rest.lower()
        best_len = 0
        best = None  # ("file", name) | ("type", exts)

        for lf, orig in lower_files.items():
            if len(lf) > best_len and rest_l.startswith(lf):
                best_len, best = len(lf), ("file", orig)

        for alias, exts in _TYPE_ALIASES.items():
            if len(alias) > best_len and rest_l.startswith(alias):
                nxt = rest[len(alias): len(alias) + 1]
                if nxt == "" or not nxt.isalnum():  # whole-token match
                    best_len, best = len(alias), ("type", exts)

        if best is None:
            i = at + 1
            continue

        spans.append((at, at + 1 + best_len))
        if best[0] == "file":
            targets.add(best[1])
        else:
            targets.update(f for f in known if f.lower().endswith(best[1]))
        i = at + 1 + best_len

    if not spans:
        return None, text

    # Strip the matched mention spans, collapse leftover whitespace.
    out, last = [], 0
    for s, e in spans:
        out.append(text[last:s])
        last = e
    out.append(text[last:])
    clean = " ".join("".join(out).split())
    return targets, clean
