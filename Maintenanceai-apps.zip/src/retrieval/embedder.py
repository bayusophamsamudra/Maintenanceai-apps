"""Sentence-Transformers embedding wrapper.

Three optimizations that matter for ingestion speed:

  1. Lazy load: model loaded only on first call so app startup is instant.
  2. GPU auto-detect + fp16: if CUDA available, use it and halve precision —
     ~2x throughput and ~50% less VRAM. This matters because Ollama also wants
     VRAM for Gemma; embedding doing fp16 leaves headroom.
  3. Batch progress callback: emit progress per batch so the UI bar moves
     smoothly during the embedding phase (otherwise looks frozen for minutes).

Prompt conventions differ per model family — get them wrong and similarity
scores collapse:
  * intfloat/multilingual-e5-*: literal "query: " / "passage: " prefixes.
  * Qwen/Qwen3-Embedding-*: an instruction prompt on the QUERY side only
    (shipped in the model's config as prompt_name="query"); passages raw.
The family is detected from EMBEDDING_MODEL's name, so swapping models in
config.py needs no code change here. NB: chunks embedded by different models
are incompatible — re-index everything after a swap (searcher guards this).
"""
import threading
from typing import Callable, Optional

try:
    import torch
    _HAS_TORCH = True
except ImportError:
    _HAS_TORCH = False

from sentence_transformers import SentenceTransformer

from src.config import EMBEDDING_MODEL

ProgressCb = Callable[[int, int], None]  # (done, total)

_model: Optional[SentenceTransformer] = None
_device: Optional[str] = None
# Serializes model construction: the warm-up daemon thread (main_window) and
# the first QueryWorker thread can both reach get_model() with _model still
# None. Without this they would each load the model into VRAM, doubling the
# footprint that already competes with Ollama for the 8GB budget.
_load_lock = threading.Lock()

_IS_QWEN = "qwen3-embedding" in EMBEDDING_MODEL.lower()
_IS_E5 = "/multilingual-e5-" in EMBEDDING_MODEL.lower() or "intfloat/e5" in EMBEDDING_MODEL.lower()

# Chunks are capped at ~800 estimated tokens; 1024 covers them with margin.
# Without this cap, long-context models (Qwen3: 32k) would allocate
# activation memory for their full window on every batch.
_MAX_SEQ = 1024


def _resolve_device() -> str:
    global _device
    if _device is None:
        if _HAS_TORCH and torch.cuda.is_available():
            _device = "cuda"
        else:
            _device = "cpu"
    return _device


def get_model() -> SentenceTransformer:
    """Lazy-loaded singleton. Uses GPU + fp16 when available.

    Double-checked locking: the cheap outer check skips the lock once loaded,
    the inner check under _load_lock is the real guard against two threads
    building the model at once. The fully-initialized model is published to
    the global only as the last step, so no thread observes a half-built one.
    """
    global _model
    if _model is None:
        with _load_lock:
            if _model is None:
                device = _resolve_device()
                model = SentenceTransformer(EMBEDDING_MODEL, device=device)
                if _HAS_TORCH and device == "cuda":
                    model = model.half()
                if model.max_seq_length and model.max_seq_length > _MAX_SEQ:
                    model.max_seq_length = _MAX_SEQ
                _model = model
    return _model


def _default_batch_size() -> int:
    """Bigger batches on GPU; conservative on CPU to avoid OOM on small RAM.

    Qwen3-0.6B is ~20x larger than e5-small — halve the GPU batch so
    activations fit alongside Ollama's resident LLM in 8GB VRAM.
    """
    if _resolve_device() == "cuda":
        return 8 if _IS_QWEN else 64
    return 4 if _IS_QWEN else 16


def _embed(
    texts: list[str],
    batch_size: int | None,
    progress_cb: ProgressCb | None,
    prompt_name: str | None = None,
) -> list[list[float]]:
    model = get_model()
    bs = batch_size or _default_batch_size()
    out: list[list[float]] = []
    total = len(texts)
    for i in range(0, total, bs):
        batch = texts[i : i + bs]
        emb = model.encode(
            batch,
            batch_size=bs,
            prompt_name=prompt_name,
            normalize_embeddings=True,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        out.extend(emb.tolist())
        if progress_cb:
            progress_cb(min(i + bs, total), total)
    return out


def embed_passages(
    texts: list[str],
    batch_size: int | None = None,
    progress_cb: ProgressCb | None = None,
) -> list[list[float]]:
    """Embed document chunks with the family's document-side convention."""
    if _IS_E5:
        texts = [f"passage: {t}" for t in texts]
    return _embed(texts, batch_size, progress_cb)


def embed_query(text: str) -> list[float]:
    """Embed a user question with the family's query-side convention."""
    if _IS_QWEN:
        return _embed([text], batch_size=1, progress_cb=None, prompt_name="query")[0]
    if _IS_E5:
        text = f"query: {text}"
    return _embed([text], batch_size=1, progress_cb=None)[0]


def device_info() -> str:
    """Human-readable info for the status bar."""
    dev = _resolve_device()
    if dev == "cuda" and _HAS_TORCH:
        name = torch.cuda.get_device_name(0)
        return f"GPU ({name}, fp16)"
    backend = "PyTorch" if _HAS_TORCH else "ONNX Runtime"
    return f"CPU ({backend})"
