"""Hybrid semantic + keyword search over the indexed chunks.

Two retrievers, fused with Reciprocal Rank Fusion (RRF):
  * Vector: exact cosine via numpy (embeddings are L2-normalized, so cosine
    = dot product). Catches meaning — paraphrases, cross-language questions.
  * Keyword: SQLite FTS5 over the same chunks. Catches exact tokens — tag
    numbers, instrument codes, table cells — where embeddings are weak.

RRF needs no score calibration between the two systems: each hit contributes
1/(K + rank), so items found by BOTH retrievers rise to the top.

The full embedding matrix is cached in memory and only reloaded when the
chunks table changes (detected via a cheap COUNT/MAX(id) stamp) — reading
hundreds of float32 blobs out of sqlite on every question was pure waste.
"""
import re
import sqlite3

import numpy as np

from src.config import (
    PRUNE_FTS_RANK,
    PRUNE_KEEP_MIN,
    RERANK_CANDIDATES,
    RERANK_ENABLED,
    TOP_K,
    TOP_K_LOOKUP,
)
from src.ingestion.indexer import connect
from src.retrieval import reranker
from src.retrieval.embedder import embed_query

_RRF_K = 60          # standard RRF constant; dampens rank-1 dominance
_CANDIDATES = 20     # how many candidates each retriever contributes

# {"stamp": (count, max_id), "rows": [...], "matrix": np.ndarray | None}
_cache: dict = {"stamp": None, "rows": [], "matrix": None}


def _cached_chunks(con: sqlite3.Connection) -> tuple[list, np.ndarray | None]:
    """Return (rows, embedding matrix), reloading only when the table changed.

    Keyed on the monotonic write-generation counter (bumped by every
    index/delete), not (COUNT, MAX(id)): SQLite reuses rowids after DELETE,
    so a same-count re-index of the highest-id file produced an identical
    (COUNT, MAX(id)) stamp and silently served stale embeddings/text.
    """
    stamp = con.execute(
        "SELECT value FROM meta WHERE key = 'generation'"
    ).fetchone()
    if stamp != _cache["stamp"]:
        rows = con.execute(
            "SELECT id, file, page, text, embedding FROM chunks"
        ).fetchall()
        matrix = None
        if rows:
            matrix = np.frombuffer(
                b"".join(r[4] for r in rows), dtype=np.float32
            ).reshape(len(rows), -1)
        _cache.update(stamp=stamp, rows=rows, matrix=matrix)
    return _cache["rows"], _cache["matrix"]


def _fts_ranks(con: sqlite3.Connection, question: str) -> dict[int, int]:
    """{chunk_id: rank} of the best keyword matches, or {} on no/bad query."""
    tokens = re.findall(r"\w+", question)
    if not tokens:
        return {}
    match = " OR ".join(f'"{t}"' for t in tokens)
    try:
        rows = con.execute(
            "SELECT rowid FROM chunks_fts WHERE chunks_fts MATCH ? "
            "ORDER BY rank LIMIT ?",
            (match, _CANDIDATES),
        ).fetchall()
    except sqlite3.OperationalError:
        return {}  # malformed FTS query — fall back to vector-only
    return {row[0]: rank for rank, row in enumerate(rows)}


# --- Exact-identifier handling: relevance gate + retrieval rescue ------------
# A "distinctive identifier" is a code/tag/part token: alphanumerics joined by
# '-' or '/', containing BOTH a letter and a digit. So 4812-ZSO-0053,
# LFR-3/4-D-MAXI-KA-A and MS-DD-4820-ICS-DWG-0528 match, but "0-16" (a pressure
# range) and "end-to-end" do not. Tune this to your naming conventions.
_IDENTIFIER_RE = re.compile(r"[A-Za-z0-9]+(?:[-/][A-Za-z0-9]+)+")


def identifiers(question: str) -> list[str]:
    """Distinctive codes / tags / part numbers mentioned in the question."""
    return [
        m
        for m in _IDENTIFIER_RE.findall(question)
        if len(m) >= 4 and any(c.isdigit() for c in m) and any(c.isalpha() for c in m)
    ]


def covers_identifiers(question: str, chunks: list[dict]) -> bool:
    """Relevance gate. True if the question names no specific identifier, or at
    least one of them literally appears in the retrieved chunks. When this is
    False, the asked-about code/tag simply is not in the index — the caller
    should say so instead of letting the LLM invent an answer from a look-alike
    row (the "answers just 'B'" failure mode).
    """
    ids = identifiers(question)
    if not ids:
        return True
    blob = " ".join(c["text"] for c in chunks).lower()
    return any(i.lower() in blob for i in ids)


def search(question: str, top_k: int = TOP_K, files=None) -> list[dict]:
    """Return the most relevant chunks for the question, pruned for prompt size.

    Note: embed_query() applies whatever query-side convention the configured
    embedding family needs (Qwen3: prompt_name="query"; E5: a literal "query:"
    prefix). Document chunks were embedded with the matching passage-side
    convention — the query/passage asymmetry is by design. See embedder.py.

    Pruning: the top PRUNE_KEEP_MIN fused results are always kept; results
    beyond that must also be confirmed by a keyword hit (FTS rank within
    PRUNE_FTS_RANK). Each chunk costs ~800 prompt tokens, so dropping
    unconfirmed tail chunks directly cuts time-to-first-token.

    Returns:
        list of {"text": str, "page": int, "file": str, "score": float}
        (score = fused RRF score). Empty list if nothing is indexed yet.
    """
    con = connect()
    try:
        rows, embeddings = _cached_chunks(con)
        if not rows:
            return []
        fts = _fts_ranks(con, question)
    finally:
        con.close()

    # Optional @-mention scoping: restrict to the named files. None = all files;
    # an empty set means the mention matched nothing indexed -> no results.
    if files is not None:
        keep = {f.lower() for f in files}
        idx = [i for i, r in enumerate(rows) if r[1].lower() in keep]
        if not idx:
            return []
        rows = [rows[i] for i in idx]
        embeddings = embeddings[idx]
        sub_ids = {r[0] for r in rows}
        fts = {cid: rk for cid, rk in fts.items() if cid in sub_ids}

    by_id = {r[0]: r for r in rows}

    # Vector ranks.
    query_emb = np.asarray(embed_query(question), dtype=np.float32)
    if embeddings.shape[1] != query_emb.shape[0]:
        raise RuntimeError(
            f"Model embedding berubah (index: {embeddings.shape[1]}d, "
            f"model sekarang: {query_emb.shape[0]}d). Bangun ulang index: "
            "hapus semua dokumen lalu tambahkan lagi, atau jalankan ulang "
            "indexing dari folder data/pdfs."
        )
    scores = embeddings @ query_emb
    # Top-_CANDIDATES via argpartition (O(N)) instead of a full argsort
    # (O(N log N)). Only the small candidate slice needs ordering; at tens of
    # thousands of chunks the full sort was the dominant per-query cost (see the
    # scaling benchmark). argpartition finds the k best unordered, then we sort
    # just those k.
    n = scores.shape[0]
    k = min(_CANDIDATES, n)
    if k < n:
        part = np.argpartition(scores, -k)[-k:]           # k largest, unordered
        vec_order = part[np.argsort(scores[part])[::-1]]  # order only those k
    else:
        vec_order = np.argsort(scores)[::-1]

    # Reciprocal Rank Fusion.
    fused: dict[int, float] = {}
    for rank, idx in enumerate(vec_order):
        chunk_id = rows[idx][0]
        fused[chunk_id] = fused.get(chunk_id, 0.0) + 1.0 / (_RRF_K + rank)
    for chunk_id, rank in fts.items():
        fused[chunk_id] = fused.get(chunk_id, 0.0) + 1.0 / (_RRF_K + rank)

    # Prune over the FULL fused ranking, THEN take top_k — not the reverse.
    # Truncating to top_k first would discard a strong keyword-only hit that
    # lands at fused rank 6+ (low vector score but FTS rank 0, e.g. an exact
    # tag number), which is precisely the case hybrid search exists to catch.
    ranked = sorted(fused.items(), key=lambda kv: kv[1], reverse=True)

    def _row(cid, score):
        return {
            "text": by_id[cid][3],
            "page": by_id[cid][2],
            "file": by_id[cid][1],
            "score": score,
        }

    if RERANK_ENABLED:
        # Cross-encoder rerank the top fused candidates, then take top_k.
        # (No-op fallback to fused order if the reranker model can't load.)
        cand = [_row(cid, score) for cid, score in ranked[:RERANK_CANDIDATES]]
        results = reranker.rerank(question, cand)[:top_k]
    else:
        kept = [
            (cid, score)
            for pos, (cid, score) in enumerate(ranked)
            if pos < PRUNE_KEEP_MIN or fts.get(cid, _CANDIDATES) < PRUNE_FTS_RANK
        ][:top_k]
        results = [_row(cid, score) for cid, score in kept]

    # Exact-identifier rescue: if the question names a code/tag that no kept
    # chunk contains, pull its exact-match row straight from the index. At
    # 20k+ chunks a specific tag can miss the fused top_k; this stops an answer
    # that IS on file from being hidden. If nothing matches anywhere, the rescue
    # adds nothing and covers_identifiers() will (correctly) report "not found".
    ids = identifiers(question)
    if ids:
        have = " ".join(r["text"] for r in results).lower()
        missing = [i for i in ids if i.lower() not in have]
        if missing:
            con = connect()
            try:
                seen = {(r["file"], r["page"], r["text"]) for r in results}
                scope_sql, scope_params = "", ()
                if files is not None:  # non-empty here (empty returned earlier)
                    scope_sql = " AND file IN (%s)" % ",".join("?" * len(files))
                    scope_params = tuple(files)
                for ident in missing:
                    # instr() = literal, case-insensitive substring match — no
                    # LIKE wildcard/escape semantics to worry about for codes
                    # that contain '/', '-', etc.
                    for f, p, t in con.execute(
                        "SELECT file, page, text FROM chunks "
                        "WHERE instr(lower(text), lower(?)) > 0" + scope_sql + " LIMIT 2",
                        (ident, *scope_params),
                    ).fetchall():
                        if (f, p, t) not in seen:
                            seen.add((f, p, t))
                            results.insert(
                                0, {"text": t, "page": p, "file": f, "score": 1.0}
                            )
            finally:
                con.close()

        # Adaptive context: for a pinpoint code/tag lookup, FOCUS each chunk to
        # the row(s) that actually contain the code and drop the rest. A table
        # chunk packs ~12 near-identical rows; the model extracts the answer
        # fine from one chunk, but mixing the answer row with distractor chunks
        # (e.g. 4822-HV-2038B next to 4822-HV-2038A) made it lose the answer and
        # say "not found". Keeping just the matching rows removes that noise.
        idl = [i.lower() for i in ids]
        focused = []
        for r in results:
            matching = [
                p for p in r["text"].split("\n\n")
                if any(i in p.lower() for i in idl)
            ]
            if matching:
                focused.append({**r, "text": "\n\n".join(matching)})
        if focused:
            results = focused[:TOP_K_LOOKUP]
    return results
