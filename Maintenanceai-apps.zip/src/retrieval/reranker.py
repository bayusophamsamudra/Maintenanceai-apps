"""Optional cross-encoder reranker (OFF by default — see config.RERANK_ENABLED).

A cross-encoder scores each (question, chunk) pair jointly, which is more
precise than bi-encoder cosine similarity — but it runs one forward pass per
candidate, so it is only applied to the top RERANK_CANDIDATES fused hits.

Hardware note: on this 8GB box it does not fit in VRAM next to qwen2.5:7b +
the embedder, so RERANK_DEVICE defaults to "cpu" (slower, ~1-3s/query). The
model is loaded lazily; if it cannot load (not enabled, model missing) this
no-ops and returns the candidates unchanged, so retrieval never breaks.
"""
from src.config import (
    RERANK_CANDIDATES,
    RERANK_DEVICE,
    RERANK_ENABLED,
    RERANK_MODEL,
)

_model = None
_failed = False


def _get():
    """Lazily load the CrossEncoder once; remember failure so we don't retry."""
    global _model, _failed
    if _model is None and not _failed:
        try:
            from sentence_transformers import CrossEncoder

            _model = CrossEncoder(RERANK_MODEL, device=RERANK_DEVICE)
        except Exception:
            _failed = True  # model missing / deps unavailable -> permanent no-op
    return _model


def rerank(question: str, results: list[dict]) -> list[dict]:
    """Reorder `results` by cross-encoder relevance to `question`.

    Only the first RERANK_CANDIDATES are re-scored; the tail (if any) is kept in
    its original order behind them. No-op when disabled or the model is absent.
    """
    if not RERANK_ENABLED or len(results) < 2:
        return results
    model = _get()
    if model is None:
        return results
    head, tail = results[:RERANK_CANDIDATES], results[RERANK_CANDIDATES:]
    try:
        scores = model.predict([(question, r["text"]) for r in head])
    except Exception:
        return results
    ordered = [r for r, _ in sorted(zip(head, scores), key=lambda x: x[1], reverse=True)]
    return ordered + tail
