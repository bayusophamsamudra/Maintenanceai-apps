"""Application-wide dark theme.

One QSS sheet on top of the Fusion style. Fusion first: it is the only
built-in style that fully respects stylesheets on every widget (the native
Windows style ignores QSS for several controls, e.g. toolbar buttons).

Palette:
    bg        #14161f   window background
    surface   #1d2029   inputs, chat, list, dialogs
    surface2  #232735   raised items (list rows, chips)
    border    #2c3040   hairlines
    accent    #4f8cff   primary actions, focus, links
    accentdim #233456   accent wash (citation chips, selection)
    green     #67d29c   answer label, success
    text      #e8eaf2   primary text
    muted     #98a0b3   secondary text
"""
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QApplication

_QSS = """
* { outline: none; }

QMainWindow, QDialog, QMessageBox {
    background: #14161f;
    color: #e8eaf2;
}
QWidget { color: #e8eaf2; font-size: 10.5pt; }
QLabel { color: #98a0b3; }
QLabel#statusLabel { color: #98a0b3; padding: 2px 2px; font-size: 9.5pt; }

QToolBar {
    background: #14161f;
    border: none;
    border-bottom: 1px solid #2c3040;
    padding: 8px 10px;
    spacing: 8px;
}
QToolBar QToolButton {
    background: #1d2029;
    color: #e8eaf2;
    border: 1px solid #2c3040;
    border-radius: 8px;
    padding: 8px 16px;
    font-weight: 600;
}
QToolBar QToolButton:hover { background: #262a38; border-color: #4f8cff; }
QToolBar QToolButton:pressed { background: #303548; }

QPushButton {
    background: #4f8cff;
    color: #0d1117;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    padding: 9px 20px;
    min-height: 18px;
}
QPushButton:hover { background: #6ba1ff; }
QPushButton:pressed { background: #3d77e8; }
QPushButton:disabled { background: #262a38; color: #6b7282; }
QPushButton#stopBtn { background: #e05d5d; color: #14161f; }
QPushButton#stopBtn:hover { background: #ef7474; }
QPushButton#dangerBtn {
    background: transparent;
    color: #d98b8b;
    border: 1px solid #4a3340;
    font-weight: 500;
}
QPushButton#dangerBtn:hover { background: #2a1d22; border-color: #e05d5d; color: #e05d5d; }

QLineEdit {
    background: #1d2029;
    border: 1px solid #2c3040;
    border-radius: 8px;
    padding: 11px 14px;
    font-size: 11pt;
    selection-background-color: #4f8cff;
    selection-color: #0d1117;
}
QLineEdit:hover { border-color: #3a4054; }
QLineEdit:focus { border-color: #4f8cff; background: #20232e; }
QLineEdit:disabled { color: #6b7282; }

QTextBrowser {
    background: #1d2029;
    border: 1px solid #2c3040;
    border-radius: 12px;
    padding: 16px 18px;
    selection-background-color: #2c3a5c;
}

/* @-mention autocomplete popup: larger, bold filenames, padded rows. */
QListView#mentionPopup {
    background: #232735;
    border: 1px solid #3f465c;
    border-radius: 8px;
    padding: 4px;
    color: #e8eaf2;
    font-size: 11pt;
    font-weight: 600;
    outline: none;
}
QListView#mentionPopup::item {
    padding: 7px 12px;
    border-radius: 6px;
}
QListView#mentionPopup::item:selected {
    background: #2c3a5c;
    color: #ffffff;
}

QListWidget {
    background: #1d2029;
    border: 1px solid #2c3040;
    border-radius: 10px;
    padding: 6px;
}
QListWidget::item {
    padding: 10px 11px;
    border-radius: 8px;
    margin: 2px 1px;
    color: #e8eaf2;
}
QListWidget::item:hover { background: #232735; }
QListWidget::item:selected { background: #2c3a5c; color: #ffffff; }

QDockWidget { color: #cdd3e0; font-weight: 600; titlebar-close-icon: none; }
QDockWidget::title {
    background: #14161f;
    padding: 12px 10px 10px 10px;
    border-bottom: 1px solid #2c3040;
}

QProgressBar {
    background: #1d2029;
    border: none;
    border-radius: 3px;
    height: 6px;
    text-align: center;
    color: #98a0b3;
    font-size: 8pt;
}
QProgressBar::chunk { background: #4f8cff; border-radius: 3px; }

QStatusBar { background: #14161f; color: #98a0b3; border-top: 1px solid #2c3040; }
QStatusBar::item { border: none; }
QStatusBar QLabel { color: #98a0b3; }

QScrollBar:vertical { background: transparent; width: 12px; margin: 4px 2px; }
QScrollBar::handle:vertical { background: #2c3040; border-radius: 5px; min-height: 36px; }
QScrollBar::handle:vertical:hover { background: #3f465c; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QScrollBar:horizontal { background: transparent; height: 12px; margin: 2px 4px; }
QScrollBar::handle:horizontal { background: #2c3040; border-radius: 5px; min-width: 36px; }
QScrollBar::handle:horizontal:hover { background: #3f465c; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background: transparent; }

QToolTip {
    background: #232735;
    color: #e8eaf2;
    border: 1px solid #3a4054;
    border-radius: 6px;
    padding: 5px 9px;
}

QMessageBox QLabel { color: #e8eaf2; }
"""

# Default stylesheet for rich text inside the chat QTextBrowser. Qt supports
# only a CSS subset here — class selectors, inline backgrounds and basic text
# properties work; border-radius / box-shadow / flexbox do NOT.
CHAT_CSS = """
a { color: #7fb0ff; text-decoration: none; }
a.cite { color: #aecbff; background-color: #233456; font-size: 9pt; }
span.who-user { color: #7fb0ff; font-weight: bold; font-size: 11pt; }
span.who-bot  { color: #67d29c; font-weight: bold; font-size: 11pt; }
span.muted    { color: #98a0b3; }
span.chip { color: #cdd3e0; background-color: #232735; }
p { margin-top: 3px; margin-bottom: 12px; line-height: 138%; }
p.q { margin-bottom: 4px; }
p.err { color: #ef8a8a; }
.wtitle { color: #e8eaf2; font-size: 19pt; font-weight: bold; }
.wsub { color: #98a0b3; font-size: 11pt; }
"""


def apply_theme(app: QApplication) -> None:
    app.setStyle("Fusion")
    app.setStyleSheet(_QSS)
    app.setFont(QFont("Segoe UI", 10))
