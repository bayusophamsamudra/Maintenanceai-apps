"""Modal dialog for adding documents to the index — files or a whole folder.

Accepts every SUPPORTED_EXTENSIONS format (pdf/docx/xlsx/pptx/txt/md).
Folder mode scans recursively. On Windows the same file can match multiple
case variants, so discovery dedupes on the lowercased resolved path.
Progress shows two levels: overall (file i of N) and within-file
(extract/chunk/embed percentage from index_document's progress callback).

A long folder run is cancellable BETWEEN files: the current file always
finishes (index_document is atomic per batch and idempotent per file), so a
cancelled run never leaves a file in a worse state than before it started.
"""
from pathlib import Path

from PyQt6.QtCore import QThread, QTimer, pyqtSignal
from PyQt6.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
)

from src.ingestion.doc_loader import SUPPORTED_EXTENSIONS
from src.ingestion.indexer import index_document

_FILE_FILTER = "Dokumen ({})".format(
    " ".join(f"*{ext}" for ext in sorted(SUPPORTED_EXTENSIONS))
)


def find_documents(folder: Path) -> list[Path]:
    """All supported documents under folder, recursive, deduped
    case-insensitively."""
    seen: set[str] = set()
    out: list[Path] = []
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS:
            key = str(p.resolve()).lower()
            if key not in seen:
                seen.add(key)
                out.append(p)
    return out


class IngestWorker(QThread):
    progress = pyqtSignal(str, float)      # (message, within-file pct 0..1)
    file_done = pyqtSignal(str, int)       # (file name, chunks added)
    file_error = pyqtSignal(str, str)      # (file name, error message)
    all_done = pyqtSignal(bool)            # (was cancelled)

    def __init__(self, paths: list[Path]):
        super().__init__()
        self.paths = paths
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        for p in self.paths:
            if self._cancel:
                break
            try:
                count = index_document(
                    p,
                    progress_cb=lambda msg, pct, name=p.name: self.progress.emit(
                        f"{name}: {msg}", pct
                    ),
                    should_cancel=lambda: self._cancel,
                )
                self.file_done.emit(p.name, count)
            except Exception as e:
                self.file_error.emit(p.name, f"{type(e).__name__}: {e}")
        self.all_done.emit(self._cancel)


class IngestDialog(QDialog):
    """auto: None shows the picker buttons; "files"/"folder" opens that
    picker immediately so toolbar actions go straight to the right dialog."""

    def __init__(self, parent=None, auto: str | None = None):
        super().__init__(parent)
        self.setWindowTitle("Tambah ke Index")
        self.setMinimumWidth(520)

        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        btn_row = QHBoxLayout()
        self.pick_btn = QPushButton("Pilih File…")
        self.pick_btn.clicked.connect(self.pick_files)
        self.folder_btn = QPushButton("Pilih Folder…")
        self.folder_btn.clicked.connect(self.pick_folder)
        btn_row.addWidget(self.pick_btn)
        btn_row.addWidget(self.folder_btn)
        layout.addLayout(btn_row)

        self.status = QLabel(
            "Pilih file (PDF, Word, Excel, PowerPoint, teks) atau satu folder."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

        self.overall_label = QLabel("")
        layout.addWidget(self.overall_label)
        self.overall_bar = QProgressBar()
        self.overall_bar.setRange(0, 100)
        layout.addWidget(self.overall_bar)

        self.file_bar = QProgressBar()
        self.file_bar.setRange(0, 100)
        layout.addWidget(self.file_bar)

        self.cancel_btn = QPushButton("Batal")
        self.cancel_btn.setObjectName("dangerBtn")
        self.cancel_btn.clicked.connect(self._cancel_clicked)
        self.cancel_btn.setEnabled(False)
        layout.addWidget(self.cancel_btn)

        self._worker: IngestWorker | None = None
        self._total = 0
        self._finished = 0
        self._results: list[str] = []

        if auto == "files":
            QTimer.singleShot(0, self.pick_files)
        elif auto == "folder":
            QTimer.singleShot(0, self.pick_folder)

    # --- pickers -----------------------------------------------------------

    def pick_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Pilih Dokumen", "", _FILE_FILTER
        )
        if files:
            self._start([Path(f) for f in files])

    def pick_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Pilih Folder Berisi Dokumen")
        if not folder:
            return
        paths = find_documents(Path(folder))
        if not paths:
            self.status.setText(f"Tidak ada dokumen yang didukung di {folder}.")
            return
        self.status.setText(f"{len(paths)} dokumen ditemukan — mulai indexing…")
        self._start(paths)

    # --- run ---------------------------------------------------------------

    def _start(self, paths: list[Path]):
        self._total = len(paths)
        self._finished = 0
        self._results = []
        self.pick_btn.setEnabled(False)
        self.folder_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self._update_overall(0.0)

        self._worker = IngestWorker(paths)
        self._worker.progress.connect(self._on_progress)
        self._worker.file_done.connect(self._on_file_done)
        self._worker.file_error.connect(self._on_file_error)
        self._worker.all_done.connect(self._on_all_done)
        self._worker.start()

    def _cancel_clicked(self):
        if self._worker is not None:
            self._worker.cancel()
            self.cancel_btn.setEnabled(False)
            self.status.setText("Membatalkan — menyelesaikan file yang sedang berjalan…")

    def _update_overall(self, current_file_pct: float):
        pct = (self._finished + current_file_pct) / max(self._total, 1)
        self.overall_bar.setValue(int(pct * 100))
        self.overall_label.setText(
            f"File {min(self._finished + 1, self._total)} dari {self._total}"
        )

    def _on_progress(self, msg: str, pct: float):
        self.status.setText(msg)
        self.file_bar.setValue(int(pct * 100))
        self._update_overall(pct)

    def _on_file_done(self, file: str, count: int):
        self._finished += 1
        if count == 0:
            self._results.append(
                f"⚠ {file}: tidak ada teks (kemungkinan hasil scan — perlu OCR)"
            )
        else:
            self._results.append(f"✓ {file}: {count} chunks")
        self._update_overall(0.0)

    def _on_file_error(self, file: str, msg: str):
        self._finished += 1
        self._results.append(f"✗ {file}: {msg}")
        self._update_overall(0.0)

    def closeEvent(self, event):
        """Never let the dialog be destroyed while IngestWorker is still
        running — Qt aborts with "QThread: Destroyed while thread is still
        running". Cancel and wait for the in-flight batch to finish. The
        cancel flag is now checked between batches, so this returns within
        one batch rather than waiting out the whole current file."""
        w = self._worker
        if w is not None and w.isRunning():
            w.cancel()
            self.status.setText("Menutup — menyelesaikan batch terakhir…")
            if not w.wait(15000):
                w.terminate()
                w.wait()
        super().closeEvent(event)

    def _on_all_done(self, cancelled: bool):
        self.pick_btn.setEnabled(True)
        self.folder_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.overall_bar.setValue(100 if not cancelled else self.overall_bar.value())
        self.file_bar.setValue(100 if not cancelled else self.file_bar.value())
        title = "Dibatalkan" if cancelled else "Selesai"
        skipped = self._total - self._finished
        summary = "\n".join(self._results) or "Tidak ada file diproses."
        if skipped:
            summary += f"\n({skipped} file dilewati karena dibatalkan)"
        self.status.setText(f"{title}. {self._finished}/{self._total} file diproses.")
        QMessageBox.information(self, title, summary)
