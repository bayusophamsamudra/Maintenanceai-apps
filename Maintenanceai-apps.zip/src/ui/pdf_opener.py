"""Open a PDF at a specific page using the OS default handler.

Uses the file:// URI scheme with a #page=N fragment. Modern PDF readers
(Edge, Chrome, Adobe Reader, Foxit, Preview on macOS) all honor that anchor.
On Windows, this typically routes through Edge if no other reader is set as
default. webbrowser.open() handles the URL-quoting and OS dispatch for us.
"""
import os
import webbrowser
from pathlib import Path


def open_pdf_at_page(pdf_path: Path, page: int) -> None:
    abs_path = pdf_path.resolve()
    uri = abs_path.as_uri() + f"#page={page}"
    webbrowser.open(uri)


def open_document(path: Path, page: int = 1) -> bool:
    """Open any indexed document with the OS default handler; only PDF readers
    honor a page anchor. Returns True if the launch was dispatched, False if it
    failed (no associated app, OS error). Failures must not propagate: this is
    called from Qt click handlers on the UI thread, where an unhandled
    exception can abort the whole app — the caller surfaces feedback instead.
    """
    try:
        if path.suffix.lower() == ".pdf":
            open_pdf_at_page(path, page)
        else:
            os.startfile(str(path.resolve()))  # noqa: S606 — OS default handler
        return True
    except Exception:
        return False
