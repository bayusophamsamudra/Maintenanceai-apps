"""Chat widget: question input + answer display with clickable citations.

Heavy work (embedding + LLM call) runs on a QThread so the UI never freezes.
Citations like "[Sumber: report.pdf hal. 42]" in the model's answer are
post-processed into clickable links via QTextBrowser's anchor mechanism.

The worker reports stages ("Mencari konteks…" → "Membaca N konteks…" →
"Menulis jawaban…") because prompt evaluation takes seconds on a local GPU —
a silent gap reads as a hang. A stop flag lets the user abort generation;
the stream loop checks it between tokens and keeps whatever already arrived.
"""
import re

from PyQt6.QtCore import Qt, QStringListModel, QThread, QUrl, QUrlQuery, pyqtSignal
from PyQt6.QtGui import QTextCursor
from PyQt6.QtWidgets import (
    QCompleter,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from src.config import PDFS_DIR
from src.ingestion.indexer import list_documents
from src.llm.ollama_client import generate_stream
from src.llm.prompt_builder import build_prompt
from src.retrieval.mentions import mention_candidates, parse_mentions
from src.retrieval.searcher import covers_identifiers, identifiers, search
from src.ui.pdf_opener import open_document
from src.ui.theme import CHAT_CSS

CITATION_RE = re.compile(
    r"\[Sumber:\s*([^\]]+?\.(?:pdf|docx|xlsx|pptx|txt|md))\s+hal\.\s*(\d+)\]",
    re.IGNORECASE,
)

# Subtle, well-spaced separator between chat turns. Qt's rich-text engine has no
# real styling for <hr> (it renders a harsh sunken rule), so a thin
# background-colored table row with margins is used instead.
_TURN_DIVIDER = (
    '<div style="margin-top:18px; margin-bottom:14px;">'
    '<table width="100%" cellspacing="0" cellpadding="0"><tr>'
    '<td style="background-color:#262a38; font-size:1px; line-height:1px;">&nbsp;</td>'
    "</tr></table></div>"
)


class MentionLineEdit(QLineEdit):
    """Question input with @-mention autocomplete.

    Typing '@' pops up a list of indexed files and type aliases (@excel, @pdf,
    @word, @ppt, @text). Selecting one scopes the search to those documents.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._completer = QCompleter(self)
        self._completer.setWidget(self)
        self._completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self._completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self._model = QStringListModel(self)
        self._completer.setModel(self._model)
        self._completer.popup().setObjectName("mentionPopup")  # for QSS styling
        self._completer.activated.connect(self._insert_completion)
        self.textEdited.connect(self._maybe_complete)

    def set_candidates(self, items: list[str]):
        self._model.setStringList(items)

    def _mention_at_cursor(self):
        before = self.text()[: self.cursorPosition()]
        at = before.rfind("@")
        if at == -1:
            return None, None
        return at, before[at:]  # (start index, fragment including '@')

    def _maybe_complete(self, _):
        at, frag = self._mention_at_cursor()
        if frag is None:
            self._completer.popup().hide()
            return
        self._completer.setCompletionPrefix(frag)
        if self._completer.completionCount() == 0:
            self._completer.popup().hide()
            return
        rect = self.cursorRect()
        rect.setWidth(self._completer.popup().sizeHintForColumn(0) + 28)
        self._completer.complete(rect)

    def _insert_completion(self, completion: str):
        at, _ = self._mention_at_cursor()
        if at is None:
            return
        pos = self.cursorPosition()
        text = self.text()
        self.setText(text[:at] + completion + " " + text[pos:])
        self.setCursorPosition(at + len(completion) + 1)


class QueryWorker(QThread):
    """Run search + LLM call off the UI thread to keep the app responsive.

    The answer is streamed: every token is emitted as it arrives so the UI
    can render progressively instead of blocking for the full generation.
    """

    stage = pyqtSignal(str)
    token = pyqtSignal(str)
    finished_with_answer = pyqtSignal(str, list)
    error = pyqtSignal(str)

    def __init__(self, question: str, files=None):
        super().__init__()
        self.question = question
        self.files = files  # None = all docs; set = @-mention scope
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        try:
            scope = "" if self.files is None else " (terbatas @mention)"
            self.stage.emit(f"Mencari konteks{scope}…")
            chunks = search(self.question, files=self.files)
            if not chunks:
                if self.files is not None:
                    msg = (
                        "Tidak ada hasil pada dokumen yang Anda sebut (@mention). "
                        "Coba tanpa mention atau periksa nama/tipe filenya."
                    )
                else:
                    msg = 'Belum ada dokumen yang di-index. Klik "Tambah Dokumen" dulu.'
                self.finished_with_answer.emit(msg, [])
                return
            # Relevance gate: if the question asks about a specific code/tag that
            # appears nowhere in the retrieved context (and the rescue lookup
            # found it nowhere in the index either), say so directly instead of
            # letting the model fabricate from a look-alike row.
            if not covers_identifiers(self.question, chunks):
                asked = ", ".join(identifiers(self.question))
                self.finished_with_answer.emit(
                    f"Tidak ditemukan informasi tentang {asked} dalam dokumen "
                    "yang ter-index. Pastikan dokumen yang memuatnya sudah "
                    "ditambahkan, atau periksa penulisan kodenya.",
                    [],
                )
                return
            files = ", ".join(sorted({c["file"] for c in chunks}))
            self.stage.emit(f"Membaca {len(chunks)} konteks dari {files}…")
            prompt = build_prompt(self.question, chunks)
            parts: list[str] = []
            for tok in generate_stream(prompt):
                if self._stop:
                    break
                parts.append(tok)
                self.token.emit(tok)
            self.finished_with_answer.emit("".join(parts), chunks)
        except Exception as e:
            self.error.emit(f"{type(e).__name__}: {e}")


class ChatWidget(QWidget):
    def __init__(self):
        super().__init__()
        self._worker: QueryWorker | None = None
        self._answer_start: int | None = None  # cursor pos where stream began
        self._user_stopped = False  # distinguishes a user abort from empty output
        self._welcome_shown = False
        self._known_files: list[str] = []  # indexed filenames, for @-mentions
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(8)

        self.history = QTextBrowser()
        self.history.setOpenLinks(False)
        self.history.document().setDefaultStyleSheet(CHAT_CSS)
        self.history.anchorClicked.connect(self._on_link_clicked)
        layout.addWidget(self.history, 1)
        self._show_welcome()

        # Indeterminate activity bar, visible only while a question runs.
        self.busy = QProgressBar()
        self.busy.setRange(0, 0)
        self.busy.setFixedHeight(4)
        self.busy.setTextVisible(False)
        self.busy.hide()
        layout.addWidget(self.busy)

        row = QHBoxLayout()
        self.input = MentionLineEdit()
        self.input.setPlaceholderText(
            "Tanya… (ketik @ untuk membatasi ke dokumen/tipe tertentu)"
        )
        self.input.returnPressed.connect(self.send)
        self.send_btn = QPushButton("Tanya  ➤")
        self.send_btn.clicked.connect(self.send)
        self.stop_btn = QPushButton("Berhenti")
        self.stop_btn.setObjectName("stopBtn")
        self.stop_btn.clicked.connect(self._stop_clicked)
        self.stop_btn.hide()
        self.clear_btn = QPushButton("Bersihkan")
        self.clear_btn.setObjectName("dangerBtn")
        self.clear_btn.setToolTip("Hapus seluruh riwayat chat")
        self.clear_btn.clicked.connect(self._clear_chat)
        row.addWidget(self.input, 1)
        row.addWidget(self.send_btn)
        row.addWidget(self.stop_btn)
        row.addWidget(self.clear_btn)
        layout.addLayout(row)

        self.status = QLabel("")
        self.status.setObjectName("statusLabel")
        layout.addWidget(self.status)

        self.refresh_mentions()

    def refresh_mentions(self):
        """Rebuild the @-mention autocomplete list from the current index.
        Called on startup and whenever documents are added/removed."""
        try:
            self._known_files = [d["file"] for d in list_documents()]
        except Exception:
            self._known_files = []
        self.input.set_candidates(mention_candidates(self._known_files))

    def send(self):
        raw = self.input.text().strip()
        if not raw or self._worker is not None:
            return
        files, clean = parse_mentions(raw, self._known_files)
        if not clean.strip():
            self.status.setText(
                "Ketik pertanyaan setelah mention, mis. “@excel berapa stok?”"
            )
            return

        self._user_stopped = False
        if self._welcome_shown:
            self.history.clear()
            self._welcome_shown = False
        self._append_html(
            f'<p class="q"><span class="who-user">Question&nbsp;›</span>&nbsp; '
            f"{self._escape(raw)}</p>"
        )
        self.input.clear()
        self._set_running(True)

        self._worker = QueryWorker(clean, files)
        self._worker.stage.connect(self.status.setText)
        self._worker.token.connect(self._on_token)
        self._worker.finished_with_answer.connect(self._on_answer)
        self._worker.error.connect(self._on_error)
        self._worker.finished.connect(self._cleanup_worker)
        self._worker.start()

    def _set_running(self, running: bool):
        self.busy.setVisible(running)
        self.send_btn.setVisible(not running)
        self.stop_btn.setVisible(running)
        self.input.setEnabled(not running)
        # Clearing mid-stream would invalidate _answer_start's cursor position.
        self.clear_btn.setEnabled(not running)
        if not running:
            self.input.setFocus()

    def _clear_chat(self):
        if self._worker is None:
            self.history.clear()
            self.status.setText("")
            self._show_welcome()

    def _show_welcome(self):
        """Minimal empty state shown on startup and after clearing the chat."""
        self.history.setHtml(
            '<div align="center">'
            "<br><br><br><br><br>"
            '<p class="wtitle">INC&nbsp;AI&nbsp;APPS</p>'
            "</div>"
        )
        self._welcome_shown = True

    def _stop_clicked(self):
        if self._worker is not None:
            self._worker.stop()
            self._user_stopped = True
            self.status.setText("Menghentikan…")

    def _on_token(self, tok: str):
        """Append a streamed token as plain text at the end of the history."""
        if self._answer_start is None:
            self._append_html('<p><span class="who-bot">Answer&nbsp;›</span>&nbsp; </p>')
            cursor = self.history.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.End)
            self._answer_start = cursor.position()
            self.status.setText("Menulis jawaban…")
        cursor = self.history.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        cursor.insertText(tok)
        self.history.setTextCursor(cursor)
        self.history.ensureCursorVisible()

    def _on_answer(self, answer: str, chunks: list):
        # An empty answer must never render as a silent bare "QnA:". Seen in
        # the wild when the LLM spent its whole token budget on hidden
        # thinking (now disabled via think=False in ollama_client) — keep a
        # visible explanation in case any other path produces no text.
        if not answer.strip():
            if self._user_stopped:
                answer = "(Dihentikan — belum ada jawaban yang dihasilkan.)"
            else:
                answer = (
                    "(Model tidak menghasilkan jawaban. Coba ulangi pertanyaan "
                    "atau ganti model di src/config.py.)"
                )
        html_answer = self._linkify_citations(self._escape(answer))
        if self._answer_start is not None:
            # Replace the streamed plain text with the final HTML so the
            # [Sumber: ...] citations become clickable links.
            cursor = self.history.textCursor()
            cursor.setPosition(self._answer_start)
            cursor.movePosition(
                QTextCursor.MoveOperation.End, QTextCursor.MoveMode.KeepAnchor
            )
            cursor.removeSelectedText()
            cursor.insertHtml(html_answer)
            self._append_html(_TURN_DIVIDER)
        else:
            self._append_html(
                f'<p><span class="who-bot">Answer&nbsp;›</span>&nbsp; '
                f"{html_answer}</p>"
            )
            self._append_html(_TURN_DIVIDER)
        self.status.setText("")

    def _on_error(self, msg: str):
        self._append_html(f'<p class="err"><b>⚠ Error:</b> {self._escape(msg)}</p>')
        self.status.setText("")

    def _cleanup_worker(self):
        self._set_running(False)
        self._worker = None
        self._answer_start = None

    def shutdown(self):
        """Stop a running query and block until the worker thread exits, so the
        widget is never destroyed while its QThread is still running (Qt aborts
        with "QThread: Destroyed while thread is still running"). The stop flag
        is checked between streamed tokens, so this returns almost immediately.
        Called from MainWindow.closeEvent."""
        w = self._worker
        if w is not None and w.isRunning():
            w.stop()
            if not w.wait(8000):
                w.terminate()
                w.wait()

    def _append_html(self, html: str):
        self.history.append(html)

    @staticmethod
    def _escape(text: str) -> str:
        # Quotes are escaped too: the linkified citation embeds the filename in
        # an href="..." attribute, so an unescaped " would break out of it.
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("\n", "<br>")
        )

    @staticmethod
    def _linkify_citations(html_text: str) -> str:
        def repl(m: re.Match) -> str:
            file = m.group(1).strip()
            page = m.group(2)
            return (
                f'<a class="cite" href="pdfopen:///{file}?page={page}">'
                f"&nbsp;📄 {file} · hal. {page}&nbsp;</a>"
            )
        return CITATION_RE.sub(repl, html_text)

    def _on_link_clicked(self, url: QUrl):
        if url.scheme() != "pdfopen":
            return
        file = url.path().lstrip("/")
        query = QUrlQuery(url)
        try:
            page = int(query.queryItemValue("page") or "1")
        except ValueError:
            page = 1
        # Resolve and confirm the target stays inside PDFS_DIR before opening.
        # The filename comes from model output, so a hallucinated citation like
        # "../../secret.pdf" must not open an arbitrary file off disk.
        doc_path = (PDFS_DIR / file).resolve()
        try:
            within = doc_path.is_relative_to(PDFS_DIR.resolve())
        except (ValueError, OSError):
            within = False
        if not (within and doc_path.exists()):
            self.status.setText(
                f"File '{file}' tidak ditemukan di data/pdfs "
                "(mungkin sudah dihapus dari disk)."
            )
        elif not open_document(doc_path, page):
            self.status.setText(
                f"Tidak bisa membuka '{file}' — tidak ada aplikasi terkait?"
            )
