"""Main application window — toolbar, documents sidebar, chat, status bar."""
import threading

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QDockWidget,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QStatusBar,
    QToolBar,
    QVBoxLayout,
    QWidget,
)

from src.config import OLLAMA_MODEL, PDFS_DIR
from src.ingestion.indexer import delete_document, list_documents
from src.llm.ollama_client import health_check, warmup
from src.retrieval.embedder import device_info, embed_query
from src.ui.chat_widget import ChatWidget
from src.ui.ingest_dialog import IngestDialog
from src.ui.pdf_opener import open_document


def _warm_up_models():
    """Pre-load the embedder and the LLM so the first question is fast.

    Runs on a plain daemon thread: pure compute, touches no Qt objects.
    Failures are ignored — the first real question will surface them.
    """
    try:
        embed_query("warmup")
    except Exception:
        pass
    try:
        warmup()
    except Exception:
        pass


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"INC AI APPS — {OLLAMA_MODEL}")
        self.resize(1080, 720)

        self.chat = ChatWidget()
        self.setCentralWidget(self.chat)

        toolbar = QToolBar()
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        add_pdf = QAction("➕ Tambah Dokumen", self)
        add_pdf.triggered.connect(lambda: self.open_ingest_dialog("files"))
        toolbar.addAction(add_pdf)
        add_folder = QAction("📁 Tambah Folder", self)
        add_folder.triggered.connect(lambda: self.open_ingest_dialog("folder"))
        toolbar.addAction(add_folder)

        self._build_docs_dock()

        status = QStatusBar()
        self.setStatusBar(status)
        dev = device_info()
        ok, detail = health_check()
        if ok:
            status.showMessage(
                f"Ollama OK — model: {OLLAMA_MODEL}  |  Embedder: {dev}"
            )
        else:
            status.showMessage(
                "Peringatan: Ollama tidak terdeteksi di localhost:11434. "
                f"Jalankan `ollama serve` lalu pull `{OLLAMA_MODEL}`. ({detail})"
            )

        threading.Thread(target=_warm_up_models, daemon=True).start()

    # --- documents sidebar ---------------------------------------------------

    def _build_docs_dock(self):
        self._docs_dock = dock = QDockWidget("Dokumen ter-index", self)
        dock.setFeatures(QDockWidget.DockWidgetFeature.NoDockWidgetFeatures)

        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        self.docs_list = QListWidget()
        self.docs_list.setToolTip("Klik dua kali untuk membuka PDF")
        self.docs_list.itemDoubleClicked.connect(self._open_doc)
        layout.addWidget(self.docs_list, 1)

        remove_btn = QPushButton("Hapus dari index")
        remove_btn.setObjectName("dangerBtn")
        remove_btn.clicked.connect(self._remove_doc)
        layout.addWidget(remove_btn)

        dock.setWidget(panel)
        dock.setMinimumWidth(260)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, dock)
        self.refresh_docs()

    def refresh_docs(self):
        self.docs_list.clear()
        docs = list_documents()
        for doc in docs:
            item = QListWidgetItem(
                f"📄  {doc['file']}\n        {doc['pages']} hal · {doc['chunks']} chunks"
            )
            item.setData(Qt.ItemDataRole.UserRole, doc["file"])
            self.docs_list.addItem(item)
        self._docs_dock.setWindowTitle(
            f"Dokumen ter-index  ·  {len(docs)}" if docs else "Dokumen ter-index"
        )
        self.chat.refresh_mentions()  # keep @-mention autocomplete in sync

    def _open_doc(self, item: QListWidgetItem):
        file = item.data(Qt.ItemDataRole.UserRole)
        doc_path = PDFS_DIR / file
        if not doc_path.exists():
            self.statusBar().showMessage(
                f"File '{file}' tidak ditemukan di data/pdfs "
                "(mungkin sudah dihapus dari disk).",
                6000,
            )
        elif not open_document(doc_path, 1):
            self.statusBar().showMessage(
                f"Tidak bisa membuka '{file}' — tidak ada aplikasi terkait?",
                6000,
            )

    def _remove_doc(self):
        item = self.docs_list.currentItem()
        if item is None:
            return
        file = item.data(Qt.ItemDataRole.UserRole)
        confirm = QMessageBox.question(
            self,
            "Hapus dari index",
            f"Hapus '{file}' dari index?\n\n"
            "File PDF-nya tetap ada di data/pdfs dan bisa ditambahkan lagi.",
        )
        if confirm == QMessageBox.StandardButton.Yes:
            delete_document(file)
            self.refresh_docs()

    # --- ingest ----------------------------------------------------------------

    def open_ingest_dialog(self, auto: str | None = None):
        IngestDialog(self, auto=auto).exec()
        self.refresh_docs()

    def closeEvent(self, event):
        """Stop and wait for the chat worker before the window tears down, so a
        question in flight can't crash the app on exit (QThread destroyed while
        running). An ingest is always inside a modal dialog, which waits for its
        own worker in IngestDialog.closeEvent."""
        self.chat.shutdown()
        super().closeEvent(event)
