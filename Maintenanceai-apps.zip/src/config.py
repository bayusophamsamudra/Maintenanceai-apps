"""Central configuration for paths, models, and tunable parameters."""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
INDEX_DB = DATA_DIR / "index.db"
PDFS_DIR = DATA_DIR / "pdfs"

# Embedding model. Qwen3-Embedding-0.6B (1024d): top-tier multilingual
# retrieval — much sharper Indonesian-question ↔ English-document matching
# than e5-small, at the cost of ~1.4GB VRAM and slower ingestion.
# Prompt conventions per family are handled in embedder.py by name detection.
# IMPORTANT: chunks embedded by different models are incompatible — after
# swapping, re-index everything (searcher raises a clear error otherwise).
# To swap back: "intfloat/multilingual-e5-small" (fastest, 384d, weakest)
#               "intfloat/multilingual-e5-base" (medium, 768d)
# The model lives in models/ inside the project: HF Hub downloads kept
# stalling on this network, so the weights were fetched once with
# resume-capable curl and are loaded from disk (no Hub contact at runtime).
_LOCAL_QWEN = BASE_DIR / "models" / "Qwen3-Embedding-0.6B"
EMBEDDING_MODEL = (
    str(_LOCAL_QWEN) if _LOCAL_QWEN.exists() else "Qwen/Qwen3-Embedding-0.6B"
)

# LLM for answering. qwen2.5:7b (Q4 ~4.7GB): strong instruction-following +
# Indonesian, fits 8GB VRAM ~fully on GPU next to the ~1.2GB embedder. Obeys the
# "say not found" rule and the citation format far better than gemma4:e2b.
# Alternatives already pulled: "gemma2:9b" (smarter but tight/slower on 8GB),
# "qwen2.5:3b" (faster). Swapping the LLM needs no re-index.
# If `ollama ps` ever shows CPU offload, drop num_ctx to ~6144 below.
OLLAMA_MODEL = "qwen2.5:7b"
OLLAMA_HOST = "http://localhost:11434"
# Keep the model resident between questions. Without this Ollama unloads
# after 5 min idle and every next question pays a full multi-GB reload.
OLLAMA_KEEP_ALIVE = "30m"

CHUNK_MAX_TOKENS = 800
TOP_K = 5
# Adaptive context: for an exact code/tag lookup the answer lives in one
# specific row, so the searcher caps the context to this many chunks (ALWAYS
# keeping the rows that contain the code) instead of TOP_K. Cuts LLM prefill
# time on lookups with no accuracy loss; broad semantic questions still use
# the full TOP_K. Set equal to TOP_K to disable.
TOP_K_LOOKUP = 3
INSERT_BATCH = 64  # chunks per embed+insert batch during ingestion

# Context pruning: chunks ranked beyond PRUNE_KEEP_MIN are sent to the LLM
# only if keyword search (FTS/BM25) also ranked them within PRUNE_FTS_RANK.
# Rationale: e5-small cosine scores are too flat to threshold (top1 vs top8
# differ by ~0.02), but BM25 rank is decisive for rare tokens (tag numbers).
# Every pruned chunk saves ~800 prompt tokens ≈ 5s of prompt eval on this GPU.
PRUNE_KEEP_MIN = 3
PRUNE_FTS_RANK = 10

# Optional cross-encoder reranker (precision boost): re-scores the top fused
# candidates with a (question, chunk) cross-encoder before they reach the LLM —
# more precise than bi-encoder cosine. OFF by default: on this 8GB GPU it does
# NOT fit alongside qwen2.5:7b + the embedder, so it defaults to CPU (adds
# ~1-3s/query) and needs its own model in models/ (fetch with curl — HF Hub
# stalls on this network). Enable only when precision matters more than latency.
# See src/retrieval/reranker.py.
RERANK_ENABLED = False
RERANK_MODEL = str(BASE_DIR / "models" / "bge-reranker-base")  # local dir or HF id
RERANK_CANDIDATES = 20   # how many fused candidates to re-score
RERANK_DEVICE = "cpu"    # "cpu" keeps VRAM for the LLM; "cuda" only if it fits

DATA_DIR.mkdir(parents=True, exist_ok=True)
PDFS_DIR.mkdir(parents=True, exist_ok=True)
