"""INC AI APPS — desktop document QnA entry point.

Setup (one-time):
    1. Install Ollama: https://ollama.com/download
    2. Pull the model:   ollama pull gemma4:e2b
    3. Install deps:     pip install -r requirements.txt

Run:
    python -m src.main
"""
import sys

from PyQt6.QtWidgets import QApplication

from src.ui.main_window import MainWindow
from src.ui.theme import apply_theme


def main():
    app = QApplication(sys.argv)
    apply_theme(app)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
