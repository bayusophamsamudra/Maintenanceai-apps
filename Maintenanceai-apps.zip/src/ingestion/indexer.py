"""Pipeline: PDF -> chunks -> batched (embed -> insert) -> SQLite + numpy.

Storage: one SQLite database (data/index.db) holding chunk text, metadata,
and the embedding as a float32 blob. Retrieval is exact brute-force cosine
in numpy — embeddings are L2-normalized, so cosine = dot product.

Why not ChromaDB: its native layers crash with access violations on this
machine (the 1.5.x Rust client corrupts the DB during add; chroma-hnswlib
segfaults deleting items from disk-loaded segments and dropping in-process
collections). At this app's scale (hundreds to a few thousand chunks) exact
numpy search is faster than HNSW anyway, and sqlite + numpy cannot segfault.

Chunks are embedded and inserted INSERT_BATCH at a time:
  * GPU stays saturated — per-chunk embedding (batch_size=1) wasted most of
    its throughput; the old per-chunk design measured ~5-10x slower.
  * One sqlite commit per batch, so a crash loses at most one batch.
  * Progress still updates every batch, so the UI bar keeps moving.
"""
from __future__ import annotations

import shutil
import sqlite3
from pathlib import Path
from typing import Callable

import numpy as np

from src.config import INDEX_DB, INSERT_BATCH, PDFS_DIR
from src.ingestion.chunker import chunk_pages
from src.ingestion.doc_loader import load_document
from src.retrieval.embedder import embed_passages

ProgressCb = Callable[[str, float], None]

_SCHEMA = """
CREATE TABLE IF NOT EXISTS chunks (
    id        INTEGER PRIMARY KEY,
    file      TEXT NOT NULL,
    page      INTEGER NOT NULL,
    text      TEXT NOT NULL,
    embedding BLOB NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chunks_file ON chunks(file);

-- Full-text mirror of chunks.text for hybrid retrieval. Vector search is
-- weak for exact-token lookups (tag numbers, codes, table cells); FTS5
-- catches those. Triggers keep it in sync with inserts/deletes.
CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
    text, content='chunks', content_rowid='id'
);
CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
    INSERT INTO chunks_fts(rowid, text) VALUES (new.id, new.text);
END;
CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
    INSERT INTO chunks_fts(chunks_fts, rowid, text)
    VALUES ('delete', old.id, old.text);
END;

-- Monotonic write-generation counter. The searcher caches the full embedding
-- matrix in memory and reloads only when this value changes. A plain
-- (COUNT, MAX(id)) stamp was insufficient: SQLite reuses rowids after DELETE,
-- so re-indexing the highest-id file with the same chunk count produced an
-- identical stamp and served stale embeddings. Every index/delete bumps this.
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value INTEGER NOT NULL);
INSERT OR IGNORE INTO meta(key, value) VALUES ('generation', 0);
"""


def connect() -> sqlite3.Connection:
    """Open a connection and ensure the schema exists.

    A new connection per operation: cheap for a local file DB, and required
    anyway because Qt worker threads can't share sqlite connections.
    """
    con = sqlite3.connect(INDEX_DB)
    con.executescript(_SCHEMA)
    # One-time FTS backfill for rows inserted before the FTS table existed.
    # NB: COUNT(*) can't detect an empty FTS index here — external-content
    # tables proxy row reads to `chunks` — so use a schema-version marker.
    if con.execute("PRAGMA user_version").fetchone()[0] < 1:
        con.execute("INSERT INTO chunks_fts(chunks_fts) VALUES ('rebuild')")
        con.execute("PRAGMA user_version = 1")
        con.commit()
    return con


def _bump_generation(con: sqlite3.Connection) -> None:
    """Increment the monotonic write-generation counter.

    Call inside the same transaction as any chunk mutation. The searcher keys
    its in-memory cache on this value, so a content change is always detected
    even when (COUNT, MAX(id)) would collide (SQLite reuses rowids on DELETE).
    """
    con.execute("UPDATE meta SET value = value + 1 WHERE key = 'generation'")


def list_documents() -> list[dict]:
    """Indexed files with chunk/page counts, for the documents sidebar."""
    con = connect()
    try:
        rows = con.execute(
            "SELECT file, COUNT(*), MAX(page) FROM chunks "
            "GROUP BY file ORDER BY file COLLATE NOCASE"
        ).fetchall()
        return [{"file": f, "chunks": c, "pages": p} for f, c, p in rows]
    finally:
        con.close()


def delete_document(file_name: str) -> int:
    """Remove a file's chunks from the index. Returns rows deleted.

    The FTS mirror follows via the AFTER DELETE trigger, and the searcher's
    in-memory matrix cache invalidates itself on its next stamp check. The
    PDF copy in data/pdfs is kept — re-adding the file re-indexes it.
    """
    con = connect()
    try:
        with con:
            cur = con.execute("DELETE FROM chunks WHERE file = ?", (file_name,))
            _bump_generation(con)
        return cur.rowcount
    finally:
        con.close()


def _on_index_failure(con, file_name: str, inserted: int, total: int) -> str:
    """Failure policy when embed/insert dies partway through a file.

    Policy chosen (Bayu, 2026-06-11): Option A — keep the partial chunks.
    They are already committed and searchable, and re-adding the same file
    replaces them wholesale, so no cleanup is needed. The old chunks are
    deleted only inside the first successful batch's transaction (see
    index_document), so a failure BEFORE any new chunk is written leaves the
    previous index of this file completely intact.

    Returns a note appended to the error message shown in the UI.
    """
    if inserted == 0:
        return (
            "Index lama file ini tidak diubah — belum ada chunk baru yang "
            "tersimpan. Coba tambahkan ulang file ini."
        )
    return (
        f"{inserted}/{total} chunk sudah tersimpan dan tetap bisa dicari. "
        f"Tambahkan ulang file ini untuk melengkapinya."
    )


def index_document(
    doc_path: Path,
    progress_cb: ProgressCb | None = None,
    should_cancel: Callable[[], bool] | None = None,
    resume: bool = False,
) -> int:
    """Index one document (PDF/DOCX/XLSX/PPTX/TXT/MD) in embed+insert batches.
    Returns number of chunks added.

    should_cancel: optional predicate checked before each batch; when it
    returns True the loop stops cleanly and the chunks written so far are
    kept. Lets the ingest dialog cancel (or close) responsively mid-file
    instead of only between files.

    resume: when True, KEEP the file's existing chunks and append only the
    missing tail (skip the first N already-embedded chunks). Used to recover a
    file whose previous indexing crashed partway, without re-embedding what was
    already done. Only safe when the existing chunks were produced by the
    current chunker (chunking is deterministic, so they are a clean prefix).

    Progress budget:
      0.00 - 0.02  : copy file
      0.02 - 0.04  : extract text
      0.04 - 0.06  : chunk
      0.06 - 1.00  : batched embed + insert, one update per batch
    """
    file_name = doc_path.name
    target_path = PDFS_DIR / file_name
    if doc_path.resolve() != target_path.resolve():
        shutil.copy2(doc_path, target_path)

    def _step(msg: str, pct: float):
        if progress_cb:
            progress_cb(msg, pct)

    # Stage 1: extract pages.
    _step(f"Reading {file_name}...", 0.02)
    pages = load_document(target_path)
    if not pages:
        _step("No extractable text — skipped.", 1.0)
        return 0

    # Stage 2: chunk all pages up-front. Chunking is CPU-cheap and small;
    # streaming it provides no benefit and complicates the loop.
    _step(f"Chunking {len(pages)} pages...", 0.04)
    chunks = chunk_pages(pages, file_name)
    if not chunks:
        _step("No chunks produced — skipped.", 1.0)
        return 0

    total = len(chunks)
    STREAM_START, STREAM_END = 0.06, 1.0
    SPAN = STREAM_END - STREAM_START

    con = connect()
    done = 0
    deleted_old = False
    start_at = 0
    try:
        if resume:
            existing = con.execute(
                "SELECT COUNT(*) FROM chunks WHERE file = ?", (file_name,)
            ).fetchone()[0]
            if existing >= total:
                _step(f"Already complete ({existing} chunks).", 1.0)
                return total
            start_at = existing  # skip the already-embedded prefix
            done = existing
            deleted_old = True   # keep the prefix; append the remaining chunks

        # Stage 3: embed + insert in batches. The prior chunks for this file
        # are deleted inside the SAME transaction as the first successful
        # insert — NOT up-front. If embedding fails before any new chunk is
        # written (GPU OOM, model load error), the previous index stays intact
        # instead of being wiped. `with con:` commits per batch, so every
        # completed batch is durable.
        for start in range(start_at, total, INSERT_BATCH):
            if should_cancel and should_cancel():
                break
            batch = chunks[start : start + INSERT_BATCH]
            embeddings = embed_passages([c["text"] for c in batch])
            rows = [
                (
                    file_name,
                    c["page"],
                    c["text"],
                    np.asarray(e, dtype=np.float32).tobytes(),
                )
                for c, e in zip(batch, embeddings)
            ]
            with con:
                if not deleted_old:
                    con.execute("DELETE FROM chunks WHERE file = ?", (file_name,))
                    deleted_old = True
                con.executemany(
                    "INSERT INTO chunks (file, page, text, embedding) VALUES (?, ?, ?, ?)",
                    rows,
                )
                _bump_generation(con)
            done += len(batch)
            pct = STREAM_START + (done / total) * SPAN
            _step(f"Indexed {done}/{total} chunks (hal. {batch[-1]['page']})", pct)
    except Exception as e:
        note = _on_index_failure(con, file_name, done, total)
        raise RuntimeError(f"{type(e).__name__}: {e} — {note}") from e
    finally:
        con.close()

    return done


# Backward-compatible alias from when the app was PDF-only.
index_pdf = index_document
