"""Page-aware PDF text extraction using PyMuPDF.

Pages are 1-indexed because that matches what users see in any PDF reader,
which keeps citation handoff to the UI trivial.

sort=True is load-bearing: form-generated PDFs (instrument spec sheets,
datasheets) draw all field LABELS in one text run and all VALUES in another.
Default extraction follows that draw order, so "Manufacturer" ends up ~100
lines away from "CAMOZZI/AVS" and no LLM can pair them again. sort=True
re-orders by visual position (top-to-bottom, left-to-right), which puts each
label and its value back on the same line.
"""
import re
from pathlib import Path

import fitz

# A tag/code token (e.g. 4822-HV-2038A, MS-DD-4822-PRO-PID-5111) — used to tell
# a data row from a header row during table reconstruction.
_CODE_RE = re.compile(r"[A-Za-z0-9]+(?:[-/][A-Za-z0-9]+)+")


def _normalize(text: str) -> str:
    """Collapse intra-line whitespace; keep line and paragraph structure.

    sort=True pads lines with spaces to mirror column alignment. That costs
    real LLM context tokens without adding meaning — label/value adjacency on
    one line is what matters. Blank lines survive as paragraph separators so
    the chunker's "\\n\\n" split keeps working.
    """
    lines = [" ".join(line.split()) for line in text.splitlines()]
    return "\n".join(lines)


def _ocr_page(page) -> str:
    """OCR a page that carries no embedded text (a scanned image).

    Requires Tesseract to be installed (PyMuPDF shells out to it). Degrades
    gracefully to "" — the page is then skipped, exactly as before — when
    Tesseract is missing, so this is safe to call unconditionally. Install
    Tesseract and the page becomes searchable automatically; add the 'ind'
    language pack and pass language="ind+eng" for Indonesian scans.
    """
    try:
        tp = page.get_textpage_ocr(full=True, dpi=150)
        return _normalize(page.get_text("text", textpage=tp, sort=True)).strip()
    except Exception:
        return ""  # Tesseract not installed / OCR failed -> skip page


def _word_lines(page, y_tol: int = 3):
    """Group a page's words into visual lines: [[(x0, text), ...], ...]."""
    words = page.get_text("words")  # (x0, y0, x1, y1, text, block, line, wno)
    words.sort(key=lambda w: (round(w[1]), w[0]))
    lines, cur, cur_y = [], [], None
    for x0, y0, x1, y1, text, *_ in words:
        if cur_y is None or abs(y0 - cur_y) <= y_tol:
            cur.append((x0, text))
            cur_y = y0 if cur_y is None else cur_y
        else:
            lines.append(sorted(cur))
            cur, cur_y = [(x0, text)], y0
    if cur:
        lines.append(sorted(cur))
    return lines


def _column_anchors(lines, merge: int = 22, frac: float = 0.25):
    """Detect column left-edges as x0 positions that recur across many lines."""
    from collections import Counter

    cnt = Counter(round(x0) for ln in lines for x0, _ in ln)
    clusters, cur = [], []
    for x in sorted(cnt):
        if cur and x - cur[-1] <= merge:
            cur.append(x)
        else:
            if cur:
                clusters.append((min(cur), sum(cnt[c] for c in cur)))
            cur = [x]
    if cur:
        clusters.append((min(cur), sum(cnt[c] for c in cur)))
    thr = max(3, len(lines) * frac)
    return sorted(a for a, c in clusters if c >= thr)


def _row_cells(line, cols):
    cells = [""] * len(cols)
    for x0, text in line:
        ci = 0
        for i, cx in enumerate(cols):
            if x0 >= cx - 6:
                ci = i
        cells[ci] = (cells[ci] + " " + text).strip()
    return cells


def _table_text(page):
    """Reconstruct a fixed-column table as "Header: value | ..." records.

    Engineering index/list PDFs lay data out in fixed columns whose headers
    appear once at the top; plain `sort=True` extraction drops the column labels
    so the model can't tell a P&ID No from a Loop No. This recovers them from
    word x-positions. Returns None when the page is not table-like (prose
    datasheets) so the caller falls back to normal text extraction.
    """
    lines = _word_lines(page)
    if len(lines) < 6:
        return None
    cols = _column_anchors(lines)
    if len(cols) < 4:
        return None
    rows = [_row_cells(ln, cols) for ln in lines]
    first_data = next(
        (i for i, c in enumerate(rows) if sum(1 for v in c if _CODE_RE.search(v)) >= 2),
        None,
    )
    if not first_data:  # no header region above the data
        return None

    headers = [""] * len(cols)
    for c in rows[:first_data]:  # merge header lines; skip sparse title lines
        if sum(1 for v in c if v) >= max(2, len(cols) // 2):
            for i, v in enumerate(c):
                if v:
                    headers[i] = (headers[i] + " " + v).strip()
    headers = [h or f"col{i + 1}" for i, h in enumerate(headers)]

    out = []
    for c in rows[first_data:]:
        parts = [f"{headers[i]}: {v}" for i, v in enumerate(c) if v and v != "-"]
        if len(parts) >= 2:
            out.append(" | ".join(parts))
    return "\n\n".join(out) if len(out) >= 3 else None


def load_pdf(pdf_path: Path) -> list[dict]:
    """Extract text from each page. Tabular pages are reconstructed with column
    labels; prose pages use sorted text; pages with no embedded text are OCR'd
    when Tesseract is available, otherwise skipped.

    Returns:
        list of {"page": int (1-indexed), "text": str}
    """
    doc = fitz.open(pdf_path)
    try:
        pages = []
        for i, page in enumerate(doc, start=1):
            raw = page.get_text("text", sort=True).strip()
            if raw:
                text = _table_text(page) or _normalize(raw)
            else:
                text = _ocr_page(page)  # scanned-page fallback (needs Tesseract)
            if text:
                pages.append({"page": i, "text": text})
        return pages
    finally:
        doc.close()
