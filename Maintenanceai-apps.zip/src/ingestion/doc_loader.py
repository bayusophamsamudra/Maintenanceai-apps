"""Multi-format document loading. Every loader returns the same shape as
pdf_loader.load_pdf(): list of {"page": int (1-indexed), "text": str}.

"Page" semantics per format — the citation unit shown as "hal. N" in answers:
    pdf   real page
    docx  pseudo-page: blocks grouped by ~printed-page worth of characters
          (.docx has no fixed pages — pagination happens at render time)
    xlsx  sheet number (sheet name is embedded in the text for the LLM)
    pptx  slide number
    txt   pseudo-page by character budget, split at line boundaries
    md    same as txt

Tables (docx/pptx/xlsx rows) are rendered as "cell | cell | cell" lines —
same label↔value adjacency principle as the PDF sort=True fix.
"""
from pathlib import Path

from src.ingestion.pdf_loader import load_pdf

SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".xlsx", ".pptx", ".txt", ".md"}

# ~one printed page of text; only affects citation granularity, not chunking.
_PAGE_CHARS = 3500
# Hard cap per xlsx sheet so a million-row export can't stall ingestion.
_MAX_XLSX_ROWS = 5000


def _paginate(blocks: list[str]) -> list[dict]:
    """Group text blocks into pseudo-pages of ~_PAGE_CHARS characters."""
    pages: list[dict] = []
    current: list[str] = []
    size = 0
    for block in blocks:
        if current and size + len(block) > _PAGE_CHARS:
            pages.append({"page": len(pages) + 1, "text": "\n\n".join(current)})
            current, size = [], 0
        current.append(block)
        size += len(block)
    if current:
        pages.append({"page": len(pages) + 1, "text": "\n\n".join(current)})
    return pages


def _table_lines(rows) -> list[str]:
    return [
        " | ".join("" if c is None else str(c).strip() for c in row)
        for row in rows
    ]


def _load_docx(path: Path) -> list[dict]:
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    doc = docx.Document(str(path))
    blocks: list[str] = []
    # iter_inner_content preserves the paragraph/table interleaving;
    # doc.paragraphs + doc.tables separately would lose document order.
    for item in doc.iter_inner_content():
        if isinstance(item, Paragraph):
            text = item.text.strip()
            if text:
                blocks.append(text)
        elif isinstance(item, Table):
            lines = _table_lines(
                [[cell.text for cell in row.cells] for row in item.rows]
            )
            lines = [ln for ln in lines if ln.replace("|", "").strip()]
            if lines:
                blocks.append("\n".join(lines))
    return _paginate(blocks)


def _is_number(v) -> bool:
    if isinstance(v, (int, float)):
        return True
    s = str(v).strip().replace(",", "").replace(".", "").replace("-", "")
    return s.isdigit()


def _looks_like_header(row) -> bool:
    """A header row has >=2 non-empty cells that are mostly text labels (not
    numbers). Used to skip title/blank rows some exports put above the header."""
    cells = [c for c in row if c is not None and str(c).strip()]
    if len(cells) < 2:
        return False
    texty = sum(1 for c in cells if not _is_number(c))
    return texty >= max(2, int(len(cells) * 0.6))


def _load_xlsx(path: Path) -> list[dict]:
    """Render each data row as a self-describing "Header: value" record.

    The column-header row is auto-detected (the first header-like row within the
    first 15 rows) rather than assumed to be row 0 — some exports put a title or
    blank rows above it, which previously produced meaningless "col1..colN"
    labels. Headers are inlined into every data row so a retrieved chunk carries
    column meaning even when it is not the first chunk of the sheet. Rows are
    separated by a blank line so the chunker (which splits on "\\n\\n") packs
    whole rows and never shreds one. Empty cells are dropped to stay compact.
    """
    import openpyxl
    from itertools import chain

    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    pages: list[dict] = []
    try:
        for sheet_no, ws in enumerate(wb.worksheets, start=1):
            row_iter = ws.iter_rows(values_only=True)

            # Buffer the first rows to locate the real header row.
            head_buf = []
            for _ in range(15):
                r = next(row_iter, None)
                if r is None:
                    break
                head_buf.append(r)
            if not head_buf:
                continue  # empty sheet

            hidx = next(
                (i for i, r in enumerate(head_buf) if _looks_like_header(r)), 0
            )
            header = head_buf[hidx]
            headers = [
                str(h).strip() if h is not None and str(h).strip() else f"col{j + 1}"
                for j, h in enumerate(header)
            ]

            data_rows = chain(head_buf[hidx + 1:], row_iter)
            records: list[str] = []
            for i, row in enumerate(data_rows):
                if i >= _MAX_XLSX_ROWS:
                    records.append(f"(… dipotong setelah {_MAX_XLSX_ROWS} baris)")
                    break
                cells = [
                    f"{headers[j] if j < len(headers) else f'col{j + 1}'}: "
                    f"{str(c).strip()}"
                    for j, c in enumerate(row)
                    if c is not None and str(c).strip()
                ]
                if cells:
                    records.append(f"[{ws.title}] " + " | ".join(cells))
            if records:
                pages.append({"page": sheet_no, "text": "\n\n".join(records)})
    finally:
        wb.close()
    return pages


def _load_pptx(path: Path) -> list[dict]:
    from pptx import Presentation

    prs = Presentation(str(path))
    pages: list[dict] = []
    for slide_no, slide in enumerate(prs.slides, start=1):
        parts: list[str] = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                text = shape.text_frame.text.strip()
                if text:
                    parts.append(text)
            if getattr(shape, "has_table", False) and shape.has_table:
                lines = _table_lines(
                    [[cell.text for cell in row.cells] for row in shape.table.rows]
                )
                parts.append("\n".join(lines))
        if parts:
            pages.append({"page": slide_no, "text": "\n\n".join(parts)})
    return pages


def _load_text(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8", errors="replace")
    blocks = [b.strip() for b in text.split("\n\n") if b.strip()]
    return _paginate(blocks)


_LOADERS = {
    ".pdf": load_pdf,
    ".docx": _load_docx,
    ".xlsx": _load_xlsx,
    ".pptx": _load_pptx,
    ".txt": _load_text,
    ".md": _load_text,
}


def load_document(path: Path) -> list[dict]:
    """Extract citable pages from any supported document type."""
    loader = _LOADERS.get(path.suffix.lower())
    if loader is None:
        raise ValueError(
            f"Format tidak didukung: {path.suffix} — "
            f"yang didukung: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )
    return loader(path)
