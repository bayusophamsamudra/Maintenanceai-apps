"""Paragraph-based chunking with a token cap measured by the REAL tokenizer.

Strategy (Choice B from plan):
  1. For each page, split text into paragraphs by double newline.
  2. Greedily combine paragraphs into a chunk while total tokens stay <= cap.
  3. If a single paragraph alone exceeds the cap, fall back to sentence split.
  4. If a single sentence still exceeds the cap (rare — tables, code, no
     punctuation), hard-split by tokens.
  5. NEVER merge across pages — one chunk = one page, so citation is exact.

Token counting uses the embedding model's OWN tokenizer (cached, CPU-only — no
GPU/VRAM). The old `words * 1.3` heuristic underestimated dense technical /
tabular text (codes, pipes, numbers) by ~1.7x: chunks averaged ~1370 real
tokens and HALF exceeded the embedder's 1024-token limit, so they were silently
truncated at embed time and vector search went blind to their tails. Sizing
with the real tokenizer makes the cap exact. A conservative char-based fallback
is used only if the tokenizer cannot load (it over-counts, so it can only make
chunks smaller, never large enough to truncate).
"""
import re

from src.config import CHUNK_MAX_TOKENS, EMBEDDING_MODEL

_tokenizer = None


def _tok():
    """Lazily load the embedding model's tokenizer (CPU; no weights on GPU)."""
    global _tokenizer
    if _tokenizer is None:
        try:
            from transformers import AutoTokenizer

            _tokenizer = AutoTokenizer.from_pretrained(EMBEDDING_MODEL)
        except Exception:
            _tokenizer = False  # sentinel -> use the char-based fallback
    return _tokenizer


def count_tokens(text: str) -> int:
    """Real token count via the embedder's tokenizer; conservative fallback.

    Fallback (chars/3) deliberately OVER-counts so a missing tokenizer can only
    make chunks smaller, never large enough to truncate at the embedder.
    """
    tk = _tok()
    if tk:
        return len(tk(text, add_special_tokens=False)["input_ids"])
    return max(1, len(text) // 3)


# Backward-compatible alias (older call sites / tests imported approx_tokens).
approx_tokens = count_tokens


# Sentence boundary: period/!/? followed by whitespace. Imperfect on
# abbreviations like "Mr.", but that's fine — these are chunking splits, not
# linguistic parses. Slightly off splits don't hurt retrieval.
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


def _hard_split(unit: str) -> list[str]:
    """Split a too-large unit into <= CHUNK_MAX_TOKENS pieces by real tokens."""
    tk = _tok()
    if tk:
        ids = tk(unit, add_special_tokens=False)["input_ids"]
        return [
            tk.decode(ids[i : i + CHUNK_MAX_TOKENS]).strip()
            for i in range(0, len(ids), CHUNK_MAX_TOKENS)
        ]
    words = unit.split()
    step = max(1, CHUNK_MAX_TOKENS // 2)  # ~2 tokens/word, conservative
    return [" ".join(words[i : i + step]) for i in range(0, len(words), step)]


def _split_oversized(unit: str) -> list[str]:
    """Recursively shrink a too-large text unit into sub-units that fit the cap.

    paragraph -> sentences -> hard token slices.
    """
    if count_tokens(unit) <= CHUNK_MAX_TOKENS:
        return [unit]

    sentences = [s.strip() for s in _SENTENCE_SPLIT.split(unit) if s.strip()]
    if len(sentences) > 1:
        out: list[str] = []
        for s in sentences:
            out.extend(_split_oversized(s))
        return out

    return [p for p in _hard_split(unit) if p]


def chunk_pages(pages: list[dict], file_name: str) -> list[dict]:
    """Chunk pages into ~CHUNK_MAX_TOKENS blocks, respecting paragraph boundaries.

    Args:
        pages: [{"page": int, "text": str}, ...] from load_pdf()
        file_name: source PDF filename, e.g. "report.pdf"

    Returns:
        list of {"text": str, "page": int, "file": str}
    """
    chunks: list[dict] = []

    for page in pages:
        page_num = page["page"]
        page_text = page["text"]

        # 1. Split into paragraphs (double-newline). Filter empties.
        raw_paragraphs = [p.strip() for p in page_text.split("\n\n") if p.strip()]

        # 2. Pre-shrink any oversized paragraphs into smaller units.
        units: list[str] = []
        for para in raw_paragraphs:
            units.extend(_split_oversized(para))

        # 3. Greedy pack: combine units until adding the next would overflow.
        current: list[str] = []
        current_tokens = 0
        for unit in units:
            unit_tokens = count_tokens(unit)
            if current and current_tokens + unit_tokens > CHUNK_MAX_TOKENS:
                chunks.append(
                    {
                        "text": "\n\n".join(current),
                        "page": page_num,
                        "file": file_name,
                    }
                )
                current = [unit]
                current_tokens = unit_tokens
            else:
                current.append(unit)
                current_tokens += unit_tokens

        # Flush remaining content for this page.
        if current:
            chunks.append(
                {
                    "text": "\n\n".join(current),
                    "page": page_num,
                    "file": file_name,
                }
            )

    return chunks
