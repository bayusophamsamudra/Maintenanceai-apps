"""Prompt construction. The brain of citation quality.

The UI parses the model output for the EXACT pattern:

    [Sumber: <filename>.pdf hal. <N>]

If the model deviates from this format, citations won't become clickable.
The prompt below uses heavy emphasis (CAPS + repeated example) to keep Gemma
on-format. Iterate on this if you observe drift in answers.
"""


def build_prompt(question: str, chunks: list[dict]) -> str:
    """Format retrieved chunks + question into a single prompt for Gemma.

    Args:
        question: user's question (Indonesian or English)
        chunks: [{"text": str, "page": int, "file": str, "score": float}, ...]

    Returns:
        full prompt string ready to send to ollama_client.generate()
    """
    # Build numbered context blocks. Each block self-labels its source so the
    # model can see exactly which file + page each fact comes from.
    context_blocks = []
    for i, c in enumerate(chunks, start=1):
        context_blocks.append(
            f"[Konteks {i}] (Sumber: {c['file']} hal. {c['page']})\n{c['text']}"
        )
    context = "\n\n---\n\n".join(context_blocks)

    return f"""Anda adalah asisten QnA yang menjawab pertanyaan HANYA berdasarkan KONTEKS dokumen di bawah ini.

ATURAN WAJIB:
1. Jawab HANYA berdasarkan informasi dalam KONTEKS. JANGAN gunakan pengetahuan luar.
2. Setiap fakta dalam jawaban WAJIB diikuti tag sumber dengan format PERSIS:
       [Sumber: <nama_file_lengkap_dengan_ekstensi> hal. <nomor>]
   Contoh: "Total pendapatan adalah Rp 5 miliar [Sumber: laporan.pdf hal. 12]."
   Salin nama file PERSIS seperti tertulis di KONTEKS (apa pun ekstensinya).
3. Jika KONTEKS tidak mengandung informasi yang relevan, jawab:
       "Tidak ditemukan informasi yang relevan dalam dokumen."
   lalu sebutkan dalam satu kalimat topik apa saja yang ADA di KONTEKS,
   agar pengguna tahu dokumen mana yang ditemukan.
4. Jawab dalam bahasa yang sama dengan pertanyaan.
5. Jawab LANGSUNG dan ringkas: berikan jawaban/nilainya saja diikuti tag
   sumber. TANPA kalimat pengantar ("Berdasarkan dokumen…"), tanpa mengulang
   pertanyaan, tanpa basa-basi. Untuk pertanyaan lookup (nilai sebuah field),
   cukup satu kalimat.

KONTEKS:
{context}

Pertanyaan: {question}

Jawaban:"""
