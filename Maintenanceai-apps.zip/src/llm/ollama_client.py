"""Thin wrapper around the official ollama client.

Ollama runs as a local HTTP server on port 11434. We keep the client surface
minimal — generate() for one-shot, generate_stream() for token streaming, and
health_check() so the UI can report a sane status on startup.
"""
from typing import Iterator

import ollama

from src.config import OLLAMA_HOST, OLLAMA_KEEP_ALIVE, OLLAMA_MODEL

_client = ollama.Client(host=OLLAMA_HOST)


# Low temperature keeps answers factual and the [Sumber: ...] citation format
# stable — small models drift off-format fast at Ollama's default (0.8).
# num_ctx 8192: TOP_K=5 chunks x ~800 tokens already exceed the 4096 default;
# silent truncation would drop context (and its citations) mid-prompt.
# num_predict caps the answer length (~the slowest part on this GPU at ~36
# tok/s): 384 is ample for a cited answer or short explanation but stops the
# model from rambling, so writing finishes sooner. The prompt also asks for
# direct, preamble-free answers — together they cut generation time without
# touching retrieval accuracy.
_OPTIONS = {"temperature": 0.2, "num_ctx": 8192, "num_predict": 384}

# think=False: gemma4:e2b is thinking-capable and, on hard prompts, spends its
# ENTIRE num_predict budget on hidden reasoning — response comes back empty
# (done_reason=length, eval_count=512, response=""). Disabling thinking makes
# it answer directly (~20x fewer tokens). Safe for non-thinking models too:
# Ollama only rejects think=True on models without the capability.
_THINK = False


def generate(prompt: str, model: str = OLLAMA_MODEL) -> str:
    """Send prompt, wait for full response, return text."""
    resp = _client.generate(
        model=model,
        prompt=prompt,
        stream=False,
        think=_THINK,
        options=_OPTIONS,
        keep_alive=OLLAMA_KEEP_ALIVE,
    )
    return resp["response"]


def generate_stream(prompt: str, model: str = OLLAMA_MODEL) -> Iterator[str]:
    """Yield tokens as they arrive. Useful for streaming UI updates."""
    stream = _client.generate(
        model=model,
        prompt=prompt,
        stream=True,
        think=_THINK,
        options=_OPTIONS,
        keep_alive=OLLAMA_KEEP_ALIVE,
    )
    for chunk in stream:
        token = chunk.get("response", "")
        if token:
            yield token


def warmup(model: str = OLLAMA_MODEL) -> None:
    """Load the model into memory ahead of the first real question."""
    _client.generate(
        model=model,
        prompt="ok",
        stream=False,
        think=_THINK,
        options={**_OPTIONS, "num_predict": 1},
        keep_alive=OLLAMA_KEEP_ALIVE,
    )


def health_check() -> tuple[bool, str]:
    """Probe Ollama. Returns (ok, detail).

    detail is "" when reachable, otherwise the underlying error text. Swallowing
    the exception made a real misconfiguration (wrong host, permission error,
    incompatible client) indistinguishable from "server not running" — the UI
    can now surface the actual reason instead of the generic warning.
    """
    try:
        _client.list()
        return True, ""
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"
